g++ -Wall -std=c++20 ./main.cpp ./gl_frontEnd.cpp -lGL -lglut -lpthread -o robots
